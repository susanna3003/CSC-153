﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * 01/30/2023
 * CSC 153
 * Susanna Quayle
 * Property Tax program to calculate sales tax on user property
 */

namespace M1HW3_quayles5806
{
    public partial class propTaxForm : Form
    {
        public propTaxForm()
        {
            InitializeComponent();
        }

        private void salesTaxButton_Click(object sender, EventArgs e)
        {
            // property tax is 64 cents per $100 so 100 and 0.64 will be used in calculation
            // declare variables
            double userPropValueDouble, propSalesTax;
            userPropValueDouble = double.Parse(userPropValue.Text);
            propSalesTax = userPropValueDouble / 100 * 0.64;
            MessageBox.Show($"Sales Tax on your Property: {propSalesTax.ToString("c")}");

        }
    }
}
