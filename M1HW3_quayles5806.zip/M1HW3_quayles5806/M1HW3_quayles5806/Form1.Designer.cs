﻿
namespace M1HW3_quayles5806
{
    partial class propTaxForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.propTaxHeader = new System.Windows.Forms.Label();
            this.propTaxPrompt = new System.Windows.Forms.Label();
            this.propValueLabel = new System.Windows.Forms.Label();
            this.userPropValue = new System.Windows.Forms.TextBox();
            this.salesTaxButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // propTaxHeader
            // 
            this.propTaxHeader.AutoSize = true;
            this.propTaxHeader.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.propTaxHeader.Location = new System.Drawing.Point(101, 33);
            this.propTaxHeader.Name = "propTaxHeader";
            this.propTaxHeader.Size = new System.Drawing.Size(591, 18);
            this.propTaxHeader.TabIndex = 0;
            this.propTaxHeader.Text = "This county\'s property tax is set at 64 cents per $100 of property value.";
            // 
            // propTaxPrompt
            // 
            this.propTaxPrompt.AutoSize = true;
            this.propTaxPrompt.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.propTaxPrompt.Location = new System.Drawing.Point(116, 84);
            this.propTaxPrompt.Name = "propTaxPrompt";
            this.propTaxPrompt.Size = new System.Drawing.Size(553, 16);
            this.propTaxPrompt.TabIndex = 1;
            this.propTaxPrompt.Text = "Input your property value below to calculate the sales tax on your property.";
            // 
            // propValueLabel
            // 
            this.propValueLabel.AutoSize = true;
            this.propValueLabel.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.propValueLabel.Location = new System.Drawing.Point(313, 142);
            this.propValueLabel.Name = "propValueLabel";
            this.propValueLabel.Size = new System.Drawing.Size(122, 16);
            this.propValueLabel.TabIndex = 2;
            this.propValueLabel.Text = "Property Value:";
            // 
            // userPropValue
            // 
            this.userPropValue.Location = new System.Drawing.Point(325, 161);
            this.userPropValue.Name = "userPropValue";
            this.userPropValue.Size = new System.Drawing.Size(100, 20);
            this.userPropValue.TabIndex = 3;
            // 
            // salesTaxButton
            // 
            this.salesTaxButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.salesTaxButton.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salesTaxButton.Location = new System.Drawing.Point(325, 260);
            this.salesTaxButton.Name = "salesTaxButton";
            this.salesTaxButton.Size = new System.Drawing.Size(100, 47);
            this.salesTaxButton.TabIndex = 4;
            this.salesTaxButton.Text = "DISPLAY SALES TAX";
            this.salesTaxButton.UseVisualStyleBackColor = false;
            this.salesTaxButton.Click += new System.EventHandler(this.salesTaxButton_Click);
            // 
            // propTaxForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.salesTaxButton);
            this.Controls.Add(this.userPropValue);
            this.Controls.Add(this.propValueLabel);
            this.Controls.Add(this.propTaxPrompt);
            this.Controls.Add(this.propTaxHeader);
            this.Name = "propTaxForm";
            this.Text = "Property Tax";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label propTaxHeader;
        private System.Windows.Forms.Label propTaxPrompt;
        private System.Windows.Forms.Label propValueLabel;
        private System.Windows.Forms.TextBox userPropValue;
        private System.Windows.Forms.Button salesTaxButton;
    }
}

