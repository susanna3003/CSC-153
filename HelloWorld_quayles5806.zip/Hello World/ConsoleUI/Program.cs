﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World");
            Console.WriteLine("Susanna Quayle");
            Console.WriteLine("I want to become proficient in C# and develop a greater understanding of programming.");
            Console.WriteLine("I have taken Python and Intro to JAVA.");
            Console.WriteLine("My previous classes covered all listed topics, but C# is completely new to me so I will be new to these topics in the C# setting.");
            Console.ReadLine();
        }
    }
}
