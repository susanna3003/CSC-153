﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PaintEstimatorPractice
{
    public partial class PaintJobEstimator : Form
    {
        public PaintJobEstimator()
        {
            InitializeComponent();
        }

        private void calcTotalButton_Click(object sender, EventArgs e)
        {
            // declare variables for num gallons paint, num hours labor, cost gallons paint, cost hours labor, and total cost
            /*
             * 115 sq feet = 1 gallon of paint and 8 hours labor
             * therefore, 1 sq feet = 0.00869 gallons paint, rounded to 0.009, and 0.0695 hours labor, rounded to 0.07
             * labor cost flat rate 20 per hour
             */
            double userSqFeetDouble, userPaintDouble, userGalPaint, userLabor, userPaintCost, userLaborCost, totalCost;
            userSqFeetDouble = double.Parse(userSqFeet.Text);
            userPaintDouble = double.Parse(userPaint.Text);
            userGalPaint = userSqFeetDouble * 0.009;
            userLabor = userSqFeetDouble * 0.07;
            userPaintCost = userGalPaint * userPaintDouble;
            userLaborCost = userLabor * 20;
            totalCost = userPaintCost + userLaborCost;
            MessageBox.Show($"Your total cost is broken down below." + "\n" + $"Gallons of paint required: {userGalPaint}" + "\n" + $"Hours of labor required: {userLabor}" + "\n"
                + $"Cost of paint: {userPaintCost.ToString("c")}" + "\n" + $"Cost of labor: {userLaborCost.ToString("c")}" + "\n" + $"Total cost: {totalCost.ToString("c")}");

        }
    }
}
