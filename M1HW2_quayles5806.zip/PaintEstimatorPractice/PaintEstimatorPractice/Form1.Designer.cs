﻿
namespace PaintEstimatorPractice
{
    partial class PaintJobEstimator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.thisPaintCo = new System.Windows.Forms.Label();
            this.headerPaintCo = new System.Windows.Forms.Label();
            this.inputRequest = new System.Windows.Forms.Label();
            this.sqFeetLabel = new System.Windows.Forms.Label();
            this.paintCostLabel = new System.Windows.Forms.Label();
            this.userSqFeet = new System.Windows.Forms.TextBox();
            this.userPaint = new System.Windows.Forms.TextBox();
            this.calcTotalButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // thisPaintCo
            // 
            this.thisPaintCo.AutoSize = true;
            this.thisPaintCo.Font = new System.Drawing.Font("Gadugi", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thisPaintCo.Location = new System.Drawing.Point(12, 55);
            this.thisPaintCo.Name = "thisPaintCo";
            this.thisPaintCo.Size = new System.Drawing.Size(618, 16);
            this.thisPaintCo.TabIndex = 0;
            this.thisPaintCo.Text = "This painting company requires 1 gallon of paint and 8 hours of labor per 115 squ" +
    "are feet of wall space.";
            // 
            // headerPaintCo
            // 
            this.headerPaintCo.AutoSize = true;
            this.headerPaintCo.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.headerPaintCo.Location = new System.Drawing.Point(178, 9);
            this.headerPaintCo.Name = "headerPaintCo";
            this.headerPaintCo.Size = new System.Drawing.Size(255, 22);
            this.headerPaintCo.TabIndex = 1;
            this.headerPaintCo.Text = "The Sharp Painting Company";
            // 
            // inputRequest
            // 
            this.inputRequest.AutoSize = true;
            this.inputRequest.Font = new System.Drawing.Font("Gadugi", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputRequest.Location = new System.Drawing.Point(12, 82);
            this.inputRequest.Name = "inputRequest";
            this.inputRequest.Size = new System.Drawing.Size(479, 16);
            this.inputRequest.TabIndex = 2;
            this.inputRequest.Text = "Please fill out the boxes below to estimate the total cost of your painting proje" +
    "ct.";
            // 
            // sqFeetLabel
            // 
            this.sqFeetLabel.AutoSize = true;
            this.sqFeetLabel.Font = new System.Drawing.Font("Gadugi", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sqFeetLabel.Location = new System.Drawing.Point(106, 165);
            this.sqFeetLabel.Name = "sqFeetLabel";
            this.sqFeetLabel.Size = new System.Drawing.Size(161, 16);
            this.sqFeetLabel.TabIndex = 3;
            this.sqFeetLabel.Text = "Square Feet of Wall Space";
            // 
            // paintCostLabel
            // 
            this.paintCostLabel.AutoSize = true;
            this.paintCostLabel.Font = new System.Drawing.Font("Gadugi", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paintCostLabel.Location = new System.Drawing.Point(370, 165);
            this.paintCostLabel.Name = "paintCostLabel";
            this.paintCostLabel.Size = new System.Drawing.Size(149, 16);
            this.paintCostLabel.TabIndex = 4;
            this.paintCostLabel.Text = "Price of Paint per Gallon";
            // 
            // userSqFeet
            // 
            this.userSqFeet.Location = new System.Drawing.Point(132, 196);
            this.userSqFeet.Name = "userSqFeet";
            this.userSqFeet.Size = new System.Drawing.Size(100, 20);
            this.userSqFeet.TabIndex = 5;
            // 
            // userPaint
            // 
            this.userPaint.Location = new System.Drawing.Point(391, 196);
            this.userPaint.Name = "userPaint";
            this.userPaint.Size = new System.Drawing.Size(100, 20);
            this.userPaint.TabIndex = 6;
            // 
            // calcTotalButton
            // 
            this.calcTotalButton.Font = new System.Drawing.Font("Gadugi", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calcTotalButton.Location = new System.Drawing.Point(246, 347);
            this.calcTotalButton.Name = "calcTotalButton";
            this.calcTotalButton.Size = new System.Drawing.Size(95, 70);
            this.calcTotalButton.TabIndex = 7;
            this.calcTotalButton.Text = "CALCULATE COST";
            this.calcTotalButton.UseVisualStyleBackColor = true;
            this.calcTotalButton.Click += new System.EventHandler(this.calcTotalButton_Click);
            // 
            // PaintJobEstimator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 575);
            this.Controls.Add(this.calcTotalButton);
            this.Controls.Add(this.userPaint);
            this.Controls.Add(this.userSqFeet);
            this.Controls.Add(this.paintCostLabel);
            this.Controls.Add(this.sqFeetLabel);
            this.Controls.Add(this.inputRequest);
            this.Controls.Add(this.headerPaintCo);
            this.Controls.Add(this.thisPaintCo);
            this.Name = "PaintJobEstimator";
            this.Text = "Paint Job Estimator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label thisPaintCo;
        private System.Windows.Forms.Label headerPaintCo;
        private System.Windows.Forms.Label inputRequest;
        private System.Windows.Forms.Label sqFeetLabel;
        private System.Windows.Forms.Label paintCostLabel;
        private System.Windows.Forms.TextBox userSqFeet;
        private System.Windows.Forms.TextBox userPaint;
        private System.Windows.Forms.Button calcTotalButton;
    }
}

